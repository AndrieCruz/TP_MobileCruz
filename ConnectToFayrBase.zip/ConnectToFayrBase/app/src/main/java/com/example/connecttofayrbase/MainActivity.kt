    package com.example.connecttofayrbase

    import androidx.appcompat.app.AppCompatActivity
    import android.os.Bundle
    import android.widget.Button
    import android.widget.EditText
    import android.widget.Toast
    import com.google.firebase.Firebase
    import com.google.firebase.database.database

    class MainActivity : AppCompatActivity() {
        data class User(val name: String, val age: String, val contact: String)

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            val N : EditText = findViewById(R.id.Name)
            val A : EditText = findViewById(R.id.Age)
            val cn : EditText = findViewById(R.id.CN)
            val S : Button = findViewById(R.id.Save)
            val D : Button = findViewById(R.id.Delete)

            // Write a message to the database
            val database = Firebase.database
            val usersRef = database.getReference("Users")
            S.setOnClickListener(){
                val n = N.text.toString().trim()
                val a = A.text.toString().trim()
                val C = cn.text.toString().trim()

                val user = User(n,a,C)
                usersRef.push().setValue(user)
                Toast.makeText(this, "Infomation Saved",Toast.LENGTH_SHORT).show()
            }
            D.setOnClickListener {
                usersRef.removeValue()
            }



        }
    }